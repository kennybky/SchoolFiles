import App from "./App.vue"
import Admin from "./components/Admin.vue"
export default {
    '/home': App,
    '/admin': Admin
  }